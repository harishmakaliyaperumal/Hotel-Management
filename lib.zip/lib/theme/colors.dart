import 'package:flutter/material.dart';
// import 'package:hotel_trips/features/auth/loginpage.dart';

class AppColors{
  AppColors._();

  // static const Color HPrimaryColor = Color(0xFF000000);
  // static const Color HPrimaryColor = Color(0xFF7bb274);
  // static const Color BackgroundColor = Color(0xFF05050f);
  // static const Color Hwhite = Colors.white;
  // static const Color kSecondaryColor = Color(0xFF0B2C47);
  // static const Color kLight = Color(0xffffffff);
  // static const Color HPrimaryColor = Color(0xFF2A6E75);

  static const Color backgroundColor = Color(0xFF2A6E75);
  static const Color primaryColor = Color(0xff013457);
  static const Color textColor = Colors.black26;
  static const Color buttonColor = Color(0xff013457);
  static const Color whiteColor = Colors.white;



}



