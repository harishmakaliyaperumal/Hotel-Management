import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';



class TokenProvider {
  static final TokenProvider _instance = TokenProvider._internal();
  factory TokenProvider() => _instance;
  TokenProvider._internal();

  final String baseUrl = 'https://www.hotels.annulartech.net';
  static const String _tokenKey = 'jwt';
  static const String _tokenExpiryKey = 'token_expiry';
  bool _isRefreshing = false;

  Future<void> saveTokenData(String? token, dynamic expiry) async {
    if (token == null) {
      print('Token is null, cannot save');
      return;
    }

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_tokenKey, token);

    // Handle expiry time
    String expiryStr;
    if (expiry == null) {
      // If no expiry provided, set default to 10 minutes from now
      expiryStr = DateTime.now().add(Duration(minutes: 10)).toIso8601String();
    } else if (expiry is String) {
      expiryStr = expiry;
    } else if (expiry is DateTime) {
      expiryStr = expiry.toIso8601String();
    } else {
      print('Invalid expiry format: $expiry');
      expiryStr = DateTime.now().add(Duration(minutes: 10)).toIso8601String();
    }

    await prefs.setString(_tokenExpiryKey, expiryStr);
    print('Saved token: $token');
    print('Saved expiry: $expiryStr');
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString(_tokenKey);
    final expiryString = prefs.getString(_tokenExpiryKey);

    print('Current Token: $token');
    print('Current Expiry: $expiryString');

    if (token == null) {
      print('Token is null');
      return null;
    }

    if (expiryString == null) {
      // If expiry is missing but token exists, set new expiry
      await saveTokenData(token, null);
      return token;
    }

    try {
      final expiry = DateTime.parse(expiryString);
      print('Token expires at: $expiry');

      if (DateTime.now().isAfter(expiry.subtract(Duration(minutes: 5)))) {
        print('Token needs refresh');
        return await refreshToken();
      }
    } catch (e) {
      print('Error parsing expiry: $e');
      await saveTokenData(token, null);
    }

    return token;
  }

  Future<String?> refreshToken() async {
    if (_isRefreshing) {
      print('Already refreshing token');
      await Future.delayed(Duration(minutes: 9));
      return getToken();
    }

    _isRefreshing = true;
    try {
      final currentToken = await getToken();
      print('Current token for refresh: $currentToken');

      if (currentToken == null) {
        print('No token available for refresh');
        return null;
      }

      final response = await http.post(
        Uri.parse('$baseUrl/user/refreshToken'),
        headers: {
          'Authorization': 'Bearer $currentToken',
          'Content-Type': 'application/json',
        },
      );

      print('Refresh response status: ${response.statusCode}');
      print('Refresh response body: ${response.body}');

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final newToken = data['jwt'] as String?;
        final newExpiry = data['expiry'] as String?;

        if (newToken != null && newExpiry != null) {
          print('New token received: $newToken');
          print('New expiry received: $newExpiry');
          await _saveTokenData(newToken, newExpiry);
          return newToken;
        } else {
          print('Invalid refresh response format');
        }
      }

      print('Token refresh failed');
      await clearToken();
      return null;
    } catch (e) {
      print('Error during refresh: $e');
      await clearToken();
      return null;
    } finally {
      _isRefreshing = false;
    }
  }

  Future<void> _saveTokenData(String token, String expiry) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_tokenKey, token);
    await prefs.setString(_tokenExpiryKey, expiry);
    print('Saved token: $token');
    print('Saved expiry: $expiry');
  }

  // Public method for saving token data from login
  // Future<void> saveTokenData(String? token, dynamic expiry) async {
  //   if (token == null) {
  //     print('Cannot save null token');
  //     return;
  //   }
  //
  //   String expiryStr;
  //   if (expiry is String) {
  //     expiryStr = expiry;
  //   } else if (expiry is DateTime) {
  //     expiryStr = expiry.toIso8601String();
  //   } else {
  //     print('Invalid expiry format');
  //     return;
  //   }
  //
  //   await _saveTokenData(token, expiryStr);
  // }

  Future<void> clearToken() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_tokenKey);
    await prefs.remove(_tokenExpiryKey);
    print('Tokens cleared');
  }
}