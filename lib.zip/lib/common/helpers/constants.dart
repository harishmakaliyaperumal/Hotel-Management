class AppConstants{
  static const appName = 'Hotel Management';

  //assets
  static const logo = 'assets/images/logo.png';
  static const slide_img_1 ='assets/images/foods/food_services_slide_img-1.png';
  static const slide_img_2 ='assets/images/foods/food_services_slide_img-2.png';
  static const slide_img_3 ='assets/images/foods/food_services_slide_img-3.png';



}