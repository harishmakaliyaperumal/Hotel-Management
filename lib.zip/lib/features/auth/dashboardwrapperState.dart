// import 'dart:async';
// import 'package:flutter/material.dart';
// import 'package:holtelmanagement/features/auth/screens/auth_page.dart';
// import 'package:holtelmanagement/features/auth/screens/login.dart';
// import 'package:provider/provider.dart';
// import '../../utility/token.dart';
// import '../customer/user_menu.dart';
// import '../dashboard/services/services_page_screens/servicedashboard.dart';
// import '../kitchenMenu/screens/kitchendashboard.dart';
//
// class DashboardWrapper extends StatefulWidget {
//   final Map<String, dynamic>? loginData;
//
//   const DashboardWrapper({Key? key, this.loginData}) : super(key: key);
//
//   @override
//   State<DashboardWrapper> createState() => DashboardWrapperState();
// }
//
// class DashboardWrapperState extends State<DashboardWrapper> {
//   Timer? _tokenCheckTimer;
//   late final AuthService _authService;
//   bool _isLoading = true;
//   bool _isInitialized = false;
//
//   @override
//   void initState() {
//     super.initState();
//     _authService = Provider.of<AuthService>(context, listen: false);
//     _initializeAuth();
//   }
//
//   Future<void> _initializeAuth() async {
//     if (widget.loginData != null && !_isInitialized) {
//       try {
//         // Initialize auth service with login data
//         await _authService.setTokens(
//           accessToken: widget.loginData!['token'] ?? '',
//           refreshToken: widget.loginData!['refreshToken'] ?? '',
//           expiry: DateTime.now().add(const Duration(hours: 1)), // Adjust based on your token expiry
//         );
//         _isInitialized = true;
//         _setupAuthHandling();
//       } catch (e) {
//         print('Error initializing auth: $e');
//         _handleAuthError();
//       }
//     } else {
//       setState(() => _isLoading = false);
//     }
//   }
//
//   void _setupAuthHandling() {
//     // Set up the logout callback
//     _authService.onLogout = () {
//       if (mounted) {
//         _navigateToLogin();
//       }
//     };
//     _startTokenCheck();
//   }
//
//   void _startTokenCheck() {
//     // Cancel existing timer if any
//     _tokenCheckTimer?.cancel();
//
//     // Initial check
//     _checkTokenAndNavigate();
//
//     // Set up periodic check every minute
//     _tokenCheckTimer = Timer.periodic(
//       const Duration(minutes: 1),
//           (_) => _checkTokenAndNavigate(),
//     );
//   }
//
//   Future<void> _checkTokenAndNavigate() async {
//     if (!mounted) return;
//
//     try {
//       final token = await _authService.getValidToken();
//       if (token == null && mounted) {
//         await _handleAuthError();
//       }
//     } catch (e) {
//       print('Error checking token: $e');
//       await _handleAuthError();
//     } finally {
//       if (mounted) {
//         setState(() => _isLoading = false);
//       }
//     }
//   }
//
//   Future<void> _handleAuthError() async {
//     if (mounted) {
//       await _authService.logout();
//       _navigateToLogin();
//     }
//   }
//
//   void _navigateToLogin() {
//     Navigator.of(context).pushAndRemoveUntil(
//       MaterialPageRoute(builder: (context) => const LoginPage()),
//           (route) => false,
//     );
//   }
//
//   @override
//   void dispose() {
//     _tokenCheckTimer?.cancel();
//     super.dispose();
//   }
//
//   Widget _buildDashboard() {
//     if (widget.loginData == null) {
//       return const LoginPage();
//     }
//
//     final userType = widget.loginData!['userType'];
//     switch (userType) {
//       case 'CUSTOMER':
//         return UserMenu(
//           userName: widget.loginData!['username'],
//           userId: widget.loginData!['id'],
//           floorId: int.tryParse(widget.loginData!['floorId']?.toString() ?? '0') ?? 0,
//           roomNo: int.tryParse(widget.loginData!['roomNo']?.toString() ?? '0') ?? 0,
//           rname: widget.loginData!['username'],
//           loginResponse: widget.loginData!,
//         );
//       case 'SERVICE':
//         return ServicesDashboard(
//           userId: widget.loginData!['id'],
//           userName: widget.loginData!['username'],
//           roomNo: widget.loginData!['roomNo']?.toString() ?? '0',
//           floorId: widget.loginData!['floorId']?.toString() ?? '0',
//         );
//       case 'RESTAURANT':
//         return const KitchenDashboard();
//       default:
//         return Scaffold(
//           body: Center(
//             child: Text(
//               'Unknown user type: $userType',
//               style: const TextStyle(fontSize: 16, color: Colors.red),
//             ),
//           ),
//         );
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     if (_isLoading) {
//       return const Scaffold(
//         body: Center(
//           child: CircularProgressIndicator(),
//         ),
//       );
//     }
//
//     return _buildDashboard();
//   }
// }