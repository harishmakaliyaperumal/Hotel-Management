// // import 'dart:convert';
// // import 'package:flutter/material.dart';
// // import 'package:http/http.dart' as http;
// // import 'dart:async';
// //
// // import '../../../common/helpers/shared_preferences_helper.dart';
// // import '../../../utility/token.dart';
// // import 'authexception.dart';
// //
// // class AuthService extends ChangeNotifier {
// //   static final AuthService _instance = AuthService._internal();
// //   factory AuthService() => _instance;
// //
// //   final String baseUrl = 'https://www.hotels.annulartech.net';
// //   final SharedPreferencesHelper _prefsHelper = SharedPreferencesHelper();
// //   final TokenProvider _tokenProvider = TokenProvider();
// //
// //   bool _isRefreshing = false;
// //   Timer? _tokenCheckTimer;
// //   final _navigationKey = GlobalKey<NavigatorState>();
// //
// //   void Function()? onLogout;
// //
// //   AuthService._internal() {
// //     // Start token check timer when service is initialized
// //     _startTokenCheckTimer();
// //   }
// //
// //   void _startTokenCheckTimer() {
// //     _tokenCheckTimer?.cancel();
// //     _tokenCheckTimer = Timer.periodic(const Duration(minutes: 1), (timer) async {
// //       final token = await getValidToken();
// //       if (token == null) {
// //         // Token is invalid or expired and couldn't be refreshed
// //         await logout();
// //         onLogout?.call();  // Trigger navigation callback
// //       }
// //     });
// //   }
// //
// //   Future<Map<String, dynamic>> login(String userEmailId, String password) async {
// //     try {
// //       final response = await http.post(
// //         Uri.parse('$baseUrl/user/login'),
// //         headers: {
// //           'Content-Type': 'application/json',
// //         },
// //         body: jsonEncode({
// //           "userEmailId": userEmailId,
// //           "userPassword": password
// //         }),
// //       );
// //
// //       if (response.statusCode == 200) {
// //         final loginData = jsonDecode(response.body);
// //         await _saveAuthData(loginData);
// //         notifyListeners();
// //         _startTokenCheckTimer();
// //         return loginData;
// //       }
// //       throw Exception('Login failed: ${response.body}');
// //     } catch (e) {
// //       print('Error during login process: $e');
// //       rethrow;
// //     }
// //   }
// //
// //   Future<void> _saveAuthData(Map<String, dynamic> loginData) async {
// //     await _prefsHelper.saveLoginData(loginData);
// //     await _tokenProvider.setLoginData(loginData);
// //
// //     // Parse and save JWT expiry
// //     if (loginData['jwt'] != null) {
// //       final jwt = loginData['jwt'];
// //       final parts = jwt.split('.');
// //       if (parts.length == 3) {
// //         final payload = json.decode(
// //             utf8.decode(base64Url.decode(base64Url.normalize(parts[1])))
// //         );
// //         final expiryTime = payload['exp'];
// //         await _prefsHelper.saveTokenExpiry(expiryTime);
// //       }
// //     }
// //   }
// //
// //   Future<String?> getValidToken() async {
// //     try {
// //       final token = await _tokenProvider.getToken();
// //       if (token == null) {
// //         final loginData = await _prefsHelper.getLoginData();
// //         if (loginData?['token'] != null) {
// //           await _tokenProvider.setLoginData(loginData!);
// //           return await _tokenProvider.getToken();
// //         }
// //         return null;
// //       }
// //
// //       // Check if token is expired or about to expire (within 5 minutes)
// //       final expiryTime = await _prefsHelper.getTokenExpiry();
// //       if (expiryTime != null) {
// //         final currentTime = DateTime.now().millisecondsSinceEpoch ~/ 1000;
// //         if (expiryTime - currentTime < 300) { // 5 minutes in seconds
// //           return await refreshToken(token);
// //         }
// //       }
// //
// //       return token;
// //     } catch (e) {
// //       print('Error in getValidToken: $e');
// //       return null;
// //     }
// //   }
// //
// //   Future<String?> refreshToken(String currentToken) async {
// //     if (_isRefreshing) {
// //       // Wait for the ongoing refresh to complete
// //       await Future.delayed(Duration(seconds: 1));
// //       return await _tokenProvider.getToken();
// //     }
// //
// //     _isRefreshing = true;
// //     try {
// //       final response = await http.post(
// //         Uri.parse('$baseUrl/user/refreshToken'),
// //         headers: {
// //           'Content-Type': 'application/json',
// //           'Authorization': 'Bearer $currentToken',
// //         },
// //         body: jsonEncode({
// //           'token': currentToken,
// //         }),
// //       );
// //
// //       if (response.statusCode == 200) {
// //         final refreshData = jsonDecode(response.body);
// //         if (refreshData['jwt'] != null) {
// //           final storedData = await _prefsHelper.getLoginData();
// //           if (storedData != null) {
// //             final updatedLoginData = Map<String, dynamic>.from(storedData);
// //             updatedLoginData['jwt'] = refreshData['jwt'];
// //             updatedLoginData['token'] = refreshData['token'];
// //             await _saveAuthData(updatedLoginData);
// //             return refreshData['token'];
// //           }
// //         }
// //       } else if (response.statusCode == 401) {
// //         // If refresh fails with 401, clear auth data but don't auto-logout
// //         await _clearAuthData();
// //         return null;
// //       }
// //       throw Exception('Token refresh failed: ${response.statusCode}');
// //     } catch (e) {
// //       print('Error during token refresh: $e');
// //       return null;
// //     } finally {
// //       _isRefreshing = false;
// //     }
// //   }
// //
// //   Future<void> _clearAuthData() async {
// //     await _prefsHelper.clearLoginData();
// //     await _tokenProvider.clearToken();
// //     notifyListeners();
// //   }
// //
// //   Future<void> logout() async {
// //     _tokenCheckTimer?.cancel();  // Stop the timer
// //     await _clearAuthData();
// //     onLogout?.call();  // Trigger navigation callback
// //   }
// //
// //   Future<bool> get isAuthenticated async {
// //     return await _tokenProvider.isAuthenticated;
// //   }
// //
// //
// //   // New method to handle API responses and auto-refresh
// //   Future<T> handleApiCall<T>(Future<T> Function(String token) apiCall) async {
// //     try {
// //       final token = await getValidToken();
// //       if (token == null) {
// //         throw AuthException('Authentication token is missing. Please log in again.');
// //       }
// //
// //       try {
// //         return await apiCall(token);
// //       } on AuthException catch (e) {
// //         // If the API call fails with 401, try refreshing the token once
// //         final newToken = await refreshToken(token);
// //         if (newToken != null) {
// //           return await apiCall(newToken);
// //         }
// //         rethrow;
// //       }
// //     } catch (e) {
// //       rethrow;
// //     }
// //   }
// // }
//
//
//
// import 'dart:async';
// import 'package:flutter/material.dart';
//
// import '../../../common/helpers/shared_preferences_helper.dart';
// import '../../services/apiservices.dart';
//
// class AuthService extends ChangeNotifier {
//   String? _accessToken;
//   String? _refreshToken;
//   Timer? _refreshTimer;
//   DateTime? _tokenExpiry;
//
//   // Callback for logout events
//   VoidCallback? onLogout;
//
//   // Buffer time before token expiry to trigger refresh (e.g., 5 minutes)
//   static const refreshBuffer = Duration(minutes: 5);
//   final ApiService _apiService = ApiService();
//
//   Future<String?> getValidToken() async {
//     if (_accessToken == null) return null;
//
//     // Check if token needs refresh
//     if (_shouldRefreshToken()) {
//       try {
//         await _refreshAccessToken();
//       } catch (e) {
//         await logout();
//         return null;
//       }
//     }
//
//     return _accessToken;
//   }
//
//   bool _shouldRefreshToken() {
//     if (_tokenExpiry == null) return true;
//     final now = DateTime.now();
//     return now.add(refreshBuffer).isAfter(_tokenExpiry!);
//   }
//
//   Future<void> setTokens({
//     required String accessToken,
//     required String refreshToken,
//     required DateTime expiry,
//   }) async {
//     _accessToken = accessToken;
//     _refreshToken = refreshToken;
//     _tokenExpiry = expiry;
//
//     // Cancel existing timer if any
//     _refreshTimer?.cancel();
//
//     // Set up refresh timer
//     final timeUntilRefresh = _tokenExpiry!.subtract(refreshBuffer).difference(DateTime.now());
//     if (timeUntilRefresh.isNegative) {
//       // Token is already near expiry, refresh immediately
//       _refreshAccessToken();
//     } else {
//       _refreshTimer = Timer(timeUntilRefresh, () {
//         _refreshAccessToken();
//       });
//     }
//
//     notifyListeners();
//   }
//
//   Future<void> _refreshAccessToken() async {
//     try {
//       if (_refreshToken == null) {
//         throw Exception('No refresh token available');
//       }
//
//       final response = await _apiService.refreshToken(_refreshToken!);
//
//       if (response.containsKey('error')) {
//         throw Exception(response['error']);
//       }
//
//       if (response['jwt'] == null) {
//         throw Exception('No token received in refresh response');
//       }
//
//       // Parse expiry from response or default to 1 hour from now
//       DateTime expiry;
//       if (response['expiry'] != null) {
//         expiry = DateTime.parse(response['expiry']);
//       } else {
//         expiry = DateTime.now().add(const Duration(hours: 1));
//       }
//
//       _accessToken = response['jwt'];
//       _tokenExpiry = expiry;
//       if (response['refreshToken'] != null) {
//         _refreshToken = response['refreshToken'];
//       }
//
//       notifyListeners();
//     } catch (e) {
//       throw Exception('Token refresh failed: $e');
//     }
//   }
//
//
//
//   Future<void> logout() async {
//     _accessToken = null;
//     _refreshToken = null;
//     _tokenExpiry = null;
//     _refreshTimer?.cancel();
//     _refreshTimer = null;
//
//     onLogout?.call();
//     notifyListeners();
//   }
// }